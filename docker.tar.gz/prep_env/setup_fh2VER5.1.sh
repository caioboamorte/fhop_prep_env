#!/usr/bin/env bash
set -euo pipefail

REBOOT_AFTER_INSTALL=0
CPU_ERROR=0

if [[ "${1:-}" == "--reboot" ]]; then
  REBOOT_AFTER_INSTALL=1
fi

log() {
  printf '\n==> %s\n' "$1"
}

warn() {
  echo "AVISO: $1"
}

confirm_continue() {
  echo
  echo "========================================"
  echo "ATENCAO"
  echo "$1"
  echo "========================================"

  while true; do
    read -rp "Deseja continuar mesmo assim? [s/N]: " resp
    case "$resp" in
      [Ss]|[Ss][Ii][Mm])
        warn "Continuando por solicitacao do usuario."
        return 0
        ;;
      ""|[Nn]|[Nn][Aa][Oo]|[Nn][ãa][Oo]|[Nn][ÃA][Oo])
        echo "Execucao cancelada."
        exit 1
        ;;
      *)
        echo "Responda com s ou n."
        ;;
    esac
  done
}

fail() {
  confirm_continue "ERRO: $1"
}

run_sudo() {
  sudo "$@"
}

repair_apt() {
  warn "Tentando corrigir dependencias e pacotes pendentes."
  run_sudo dpkg --configure -a || true
  run_sudo apt-get install -f -y || true
  run_sudo apt --fix-broken install -y || true
}

update_system_packages() {
  log "Atualizando sistema operacional"

  if ! run_sudo apt update; then
    repair_apt
    run_sudo apt update || fail "Falha ao atualizar a lista de pacotes mesmo apos as correcoes."
  fi

  if ! run_sudo env DEBIAN_FRONTEND=noninteractive apt upgrade -y; then
    repair_apt
    run_sudo env DEBIAN_FRONTEND=noninteractive apt upgrade -y || \
      fail "Falha ao atualizar os pacotes mesmo apos as correcoes."
  fi

  if run_sudo apt-get check >/dev/null 2>&1; then
    echo "Atualizacao do sistema concluida sem dependencias quebradas."
  else
    repair_apt
    run_sudo apt-get check >/dev/null 2>&1 || \
      fail "O sistema ainda possui dependencias quebradas apos as tentativas de reparo."
  fi

  run_sudo apt autoremove -y || warn "Nao foi possivel remover pacotes obsoletos."
  run_sudo apt autoclean -y || warn "Nao foi possivel limpar o cache de pacotes."
}

check_command() {
  command -v "$1" >/dev/null 2>&1
}

install_recommended_docker() {
  local script_dir docker_archive install_script uninstall_script docker_scripts_dir
  local docker_detected=0 compose_detected=0 response

  script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  docker_archive="$script_dir/docker.tar.gz"
  install_script=""
  uninstall_script=""
  docker_scripts_dir=""

  log "Verificando Docker e Docker Compose"

  if check_command docker; then
    docker_detected=1
    echo "Docker detectado:"
    docker --version || true

    if docker compose version >/dev/null 2>&1; then
      compose_detected=1
      echo "Docker Compose detectado:"
      docker compose version || true
    elif check_command docker-compose; then
      compose_detected=1
      echo "Docker Compose legado detectado:"
      docker-compose --version || true
    else
      echo "Docker Compose nao foi detectado."
    fi
  else
    echo "Docker nao foi detectado."

    if check_command docker-compose; then
      compose_detected=1
      echo "Docker Compose legado detectado:"
      docker-compose --version || true
    else
      echo "Docker Compose nao foi detectado."
    fi
  fi

  if [[ "$docker_detected" -eq 1 || "$compose_detected" -eq 1 ]]; then
    while true; do
      read -rp "Deseja desinstalar a versao atual e instalar a versao recomendada? [s/N]: " response
      case "$response" in
        [Ss]|[Ss][Ii][Mm])
          break
          ;;
        ""|[Nn]|[Nn][Aa][Oo]|[Nn][ãa][Oo]|[Nn][ÃA][Oo])
          warn "Docker atual mantido. A instalacao recomendada foi ignorada."
          DOCKER_STATUS="Mantido sem alteracoes"
          return 0
          ;;
        *)
          echo "Responda com s ou n."
          ;;
      esac
    done
  fi

  if [[ ! -f "$docker_archive" ]]; then
    fail "Arquivo docker.tar.gz nao encontrado em: $script_dir"
    DOCKER_STATUS="Arquivo nao encontrado"
    return 1
  fi

  log "Descompactando pacote Docker recomendado"
  tar -xzvf "$docker_archive" -C "$script_dir"

  # Localiza os scripts mesmo que o tar.gz tenha criado uma pasta adicional.
  install_script="$(find "$script_dir" -maxdepth 5 -type f -name 'install_docker.sh' -print -quit)"
  uninstall_script="$(find "$script_dir" -maxdepth 5 -type f -name 'uninstall_docker.sh' -print -quit)"

  if [[ -z "$install_script" || ! -f "$install_script" ]]; then
    echo "Conteudo encontrado apos a extracao:"
    find "$script_dir" -maxdepth 5 -type f -printf '  %p\n' || true
    fail "Script install_docker.sh nao encontrado apos descompactar $docker_archive."
    DOCKER_STATUS="Instalador nao encontrado"
    return 1
  fi

  docker_scripts_dir="$(dirname "$install_script")"
  echo "Instalador localizado em: $install_script"

  run_sudo chmod +x "$install_script"

  if [[ "$docker_detected" -eq 1 || "$compose_detected" -eq 1 ]]; then
    if [[ -z "$uninstall_script" || ! -f "$uninstall_script" ]]; then
      echo "Conteudo encontrado apos a extracao:"
      find "$script_dir" -maxdepth 5 -type f -printf '  %p\n' || true
      fail "Script uninstall_docker.sh nao encontrado apos descompactar $docker_archive."
      DOCKER_STATUS="Desinstalador nao encontrado"
      return 1
    fi

    echo "Desinstalador localizado em: $uninstall_script"
    run_sudo chmod +x "$uninstall_script"

    log "Desinstalando Docker existente"
    (
      cd "$(dirname "$uninstall_script")"
      run_sudo ./uninstall_docker.sh
    )
  fi

  log "Instalando Docker recomendado"
  (
    cd "$docker_scripts_dir"
    run_sudo ./install_docker.sh
  )

  echo "Versoes instaladas:"
  if check_command docker; then
    docker --version || true
  fi

  if check_command docker && docker compose version >/dev/null 2>&1; then
    docker compose version || true
  elif check_command docker-compose; then
    docker-compose --version || true
  fi

  DOCKER_STATUS="Versao recomendada instalada"
}


install_google_chrome() {
  local chrome_package="/tmp/google-chrome-stable_current_amd64.deb"
  local chrome_real_bin=""

  log "Verificando Google Chrome"

  if check_command google-chrome-stable; then
    chrome_real_bin="$(command -v google-chrome-stable)"
    echo "Google Chrome ja instalado:"
    "$chrome_real_bin" --version || true
  elif [[ -x /usr/bin/google-chrome ]]; then
    chrome_real_bin="/usr/bin/google-chrome"
    echo "Google Chrome ja instalado:"
    "$chrome_real_bin" --version || true
  else
    log "Baixando Google Chrome"
    rm -f "$chrome_package"

    if ! curl -fL --retry 3 --connect-timeout 20 \
      "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb" \
      -o "$chrome_package"; then
      fail "Nao foi possivel baixar o instalador do Google Chrome."
      CHROME_STATUS="Falha no download"
      return 1
    fi

    log "Instalando Google Chrome"
    if ! run_sudo apt install -y "$chrome_package"; then
      repair_apt
      run_sudo apt install -y "$chrome_package" || {
        fail "Nao foi possivel instalar o Google Chrome."
        CHROME_STATUS="Falha na instalacao"
        return 1
      }
    fi

    rm -f "$chrome_package"

    if check_command google-chrome-stable; then
      chrome_real_bin="$(command -v google-chrome-stable)"
    elif [[ -x /usr/bin/google-chrome ]]; then
      chrome_real_bin="/usr/bin/google-chrome"
    else
      fail "Google Chrome foi instalado, mas o executavel nao foi encontrado."
      CHROME_STATUS="Executavel nao encontrado"
      return 1
    fi
  fi

  log "Configurando Google Chrome para usar --no-sandbox"

  run_sudo tee /usr/local/bin/google-chrome >/dev/null <<EOF
#!/usr/bin/env bash
exec "$chrome_real_bin" --no-sandbox "\$@"
EOF

  run_sudo chmod +x /usr/local/bin/google-chrome
  run_sudo ln -sfn /usr/local/bin/google-chrome /usr/local/bin/google-chrome-no-sandbox

  CHROME_VERSION="$("$chrome_real_bin" --version 2>/dev/null || echo 'Versao nao identificada')"
  CHROME_STATUS="Instalado e configurado com --no-sandbox"

  echo "$CHROME_VERSION"
  echo "Comando configurado: google-chrome"
}

check_cpu_required() {
  local flag="$1"
  local name="$2"

  if [[ " $CPU_FLAGS " == *" $flag "* ]]; then
    printf "  [OK]    %s\n" "$name"
  else
    printf "  [ERRO]  %s nao suportado\n" "$name"
    CPU_ERROR=1
  fi
}

log "Verificando Ubuntu"

if [[ ! -f /etc/os-release ]]; then
  fail "Nao foi possivel identificar o sistema operacional."
fi

source /etc/os-release

if [[ "${ID:-}" != "ubuntu" ]]; then
  fail "Sistema nao suportado. Este script foi feito para Ubuntu."
fi

if [[ "${VERSION_ID:-}" != "22.04" && "${VERSION_ID:-}" != "24.04" ]]; then
  fail "Ubuntu ${VERSION_ID:-desconhecido} nao suportado. Use Ubuntu 22.04 ou 24.04."
fi

echo "Ubuntu $VERSION_ID OK"

log "Verificando CPU"

CPU_MODEL="$(grep -m1 'model name' /proc/cpuinfo | cut -d ':' -f2- | xargs)"
CPU_FLAGS="$(grep -m1 '^flags' /proc/cpuinfo || true)"

echo "CPU: $CPU_MODEL"
echo

echo "Instrucoes obrigatorias:"
check_cpu_required sse4_2 "SSE4.2"
check_cpu_required popcnt "POPCNT"
check_cpu_required avx "AVX"
check_cpu_required avx2 "AVX2"

VIRTUALIZATION_STATUS="Nao verificada"

if [[ "$CPU_ERROR" -ne 0 ]]; then
  fail "CPU nao suporta todas as instrucoes obrigatorias: SSE4.2, POPCNT, AVX e AVX2."
fi

CPU_STATUS="OK"

log "Verificando memoria RAM"

RAM_GB="$(awk '/MemTotal/ {printf "%.0f", $2/1024/1024}' /proc/meminfo)"
echo "RAM detectada: ${RAM_GB} GB"

if (( RAM_GB < 32 )); then
  fail "RAM insuficiente. Minimo recomendado: 32 GB."
else
  echo "RAM OK"
fi

log "Verificando espaco em disco"

DISK_FREE_GB="$(df -BG . | awk 'NR==2 {gsub("G","",$4); print $4}')"
echo "Espaco livre na particao atual: ${DISK_FREE_GB} GB"

if (( DISK_FREE_GB < 500 )); then
  fail "Espaco em disco insuficiente. Recomendado: pelo menos 500 GB livres."
else
  echo "Disco OK"
fi

update_system_packages

log "Instalando utilitarios necessarios"
run_sudo apt install -y pciutils ubuntu-drivers-common curl ca-certificates iputils-ping

log "Verificando GPU NVIDIA"

GPU_NVIDIA="$(lspci | grep -i nvidia || true)"

if [[ -z "$GPU_NVIDIA" ]]; then
  warn "Nenhuma GPU NVIDIA detectada."
  NVIDIA_STATUS="Nao detectada"
  NVIDIA_DRIVER_STATUS="Nao instalado"
else
  echo "$GPU_NVIDIA"
  NVIDIA_STATUS="Detectada"

  if check_command nvidia-smi && nvidia-smi >/dev/null 2>&1; then
    echo "Driver NVIDIA ja esta instalado e funcionando."
    NVIDIA_DRIVER_STATUS="$(nvidia-smi --query-gpu=driver_version --format=csv,noheader | head -n1)"
  else
    log "Driver NVIDIA nao encontrado. Instalando driver recomendado."

    if echo "$GPU_NVIDIA" | grep -qiE 'RTX 5000|RTX PRO 5000|RTX 5080'; then
      log "GPU RTX 5000/5080 detectada. Instalando driver NVIDIA open recomendado."

      OPEN_DRIVER="$(ubuntu-drivers devices | awk '/nvidia-driver-[0-9]+-open/ && /recommended/ {print $3; exit}')"

      if [[ -z "$OPEN_DRIVER" ]]; then
        OPEN_DRIVER="$(ubuntu-drivers devices | awk '/nvidia-driver-[0-9]+-open/ {print $3; exit}')"
      fi

      if [[ -z "$OPEN_DRIVER" ]]; then
        fail "Nao foi encontrado driver NVIDIA open recomendado."
      else
        run_sudo apt install -y "$OPEN_DRIVER"
        NVIDIA_DRIVER_STATUS="$OPEN_DRIVER"
      fi
    else
      RECOMMENDED_DRIVER="$(ubuntu-drivers devices | awk '/recommended/ {print $3; exit}')"

      if [[ -z "$RECOMMENDED_DRIVER" ]]; then
        fail "Nao foi encontrado driver NVIDIA recomendado."
        NVIDIA_DRIVER_STATUS="Nao identificado"
      else
        run_sudo apt install -y "$RECOMMENDED_DRIVER"
        NVIDIA_DRIVER_STATUS="$RECOMMENDED_DRIVER"
      fi
    fi
  fi
fi

log "Configurando locale en_US.UTF-8"
run_sudo locale-gen en_US.UTF-8
run_sudo update-locale LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8

log "Configurando timezone America/Sao_Paulo"
run_sudo timedatectl set-timezone America/Sao_Paulo

log "Verificando conectividade com Internet"

if ping -c 2 8.8.8.8 >/dev/null 2>&1; then
  echo "Internet OK"
else
  fail "Sem conectividade com Internet."
fi

log "Verificando DNS"

if getent hosts google.com >/dev/null 2>&1; then
  echo "DNS OK"
else
  fail "Resolucao DNS falhou."
fi

CHROME_STATUS="Nao verificado"
CHROME_VERSION="Nao identificado"

log "Verificando sincronizacao de horario"

run_sudo timedatectl set-ntp true

if timedatectl | grep -q "System clock synchronized: yes"; then
  echo "NTP OK"
else
  warn "NTP habilitado, mas a sincronizacao ainda nao foi confirmada."
fi

log "Desabilitando firewall UFW"

if check_command ufw; then
  run_sudo ufw disable || true
  FIREWALL_STATUS="Desabilitado"
else
  FIREWALL_STATUS="UFW nao instalado"
fi

echo "Firewall: $FIREWALL_STATUS"

DOCKER_STATUS="Nao verificado"
install_recommended_docker

log "Criando estrutura de diretorios"

# Instalação do FlightHub OP
run_sudo mkdir -p /fhop-install/install

# Dados do FlightHub OP
run_sudo mkdir -p /data/fhop-data

# Instalação do Terra
run_sudo mkdir -p /terra-install

# Instalação do módulo 4G
run_sudo mkdir -p /4G-install

echo "Estrutura de diretorios criada com sucesso."

echo
echo "=============================="
echo " FlightHub 2 OP Pre-Check"
echo "=============================="
echo "Ubuntu............. $VERSION_ID OK"
echo "CPU................ $CPU_MODEL"
echo "CPU Recursos....... $CPU_STATUS"
echo "Virtualizacao...... $VIRTUALIZATION_STATUS"
echo "RAM................ ${RAM_GB} GB"
echo "Disco Livre........ ${DISK_FREE_GB} GB"
echo "GPU NVIDIA......... $NVIDIA_STATUS"
echo "Driver NVIDIA...... $NVIDIA_DRIVER_STATUS"
echo "Internet........... OK"
echo "DNS................ OK"
echo "Firewall........... $FIREWALL_STATUS"
echo "Docker............. $DOCKER_STATUS"
echo "Chrome............. $CHROME_STATUS"
echo "Chrome versao...... $CHROME_VERSION"
echo "Pastas............. Criadas"
echo "=============================="
echo

install_google_chrome

echo "Chrome............. $CHROME_STATUS"
echo "Chrome versao...... $CHROME_VERSION"

if [[ "$REBOOT_AFTER_INSTALL" -eq 1 ]]; then
  log "Reiniciando o sistema"
  run_sudo reboot
else
  echo "Concluido. Reinicie depois para ativar o driver NVIDIA, caso ele tenha sido instalado agora:"
  echo "  sudo reboot"
fi
